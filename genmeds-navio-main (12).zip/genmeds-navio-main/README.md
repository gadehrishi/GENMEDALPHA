node js required


run in git Bash


go into project file (cd)


npm install


https://tailwindcss.com/docs/installation/using-vite (React vite)


npm install -D tailwindcss postcss autofixer


npm i lucide-react


npm run dev
